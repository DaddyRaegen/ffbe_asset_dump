FFBE unit bundles, 2026-10-09

22 GL/JP collision forms, 21 formerly omitted asset-only forms,
and 17 repaired complete source bundles (60 forms total).
Each folder contains original texture pages, all available animation CSVs,
illustrations, icons and companions for its exact form. Native filenames
are preserved. Choose the GL or JP folder before choosing a colliding ID.
Do not combine GL and JP folders. Use manifest.json for provenance/hashes.

Use each manifest animation_set to keep main/OD/effect inputs together.
Known unusable source sequences are flagged and excluded from active sets;
their original files remain in this pack for archival completeness.

The regional and repaired forms have coherent source archives. Asset-only forms
retain legacy assets with unknown regional identity/revision status.
9990196 has no icon or illustration in the source dump. No placeholders
or gameplay metadata were invented. This is a source-input pack, not GIFs.
